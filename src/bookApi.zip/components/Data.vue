<template>
  <div class="pad">
    <ul class="list-group">
      <li class="list-group-item d-flex justify-content-between align-items-center"
          v-for="(Data,item) in response" :key="item.id">
        {{Data.title_suggest}}
        <b-button @click="getTitle(Data.title_suggest)" variant="primary">Print</b-button>
      </li>
    </ul>
  </div>
</template>

<script>

  export default {
    name: 'Data',
    props: {
      Data: {
        type:String,
      }
    },
    data() {
      return {
      };
    },
    methods: {
      getTitle(data1) {
        this.$router.push({
          name: 'title1',
          params: { title1: data1 },
        });
      },
    }
  };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .pad{
    padding: 20px;
  }

</style>
