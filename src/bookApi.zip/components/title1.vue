<template>
  <div class="bgg">
  <div class="container">
    <table class="table table-striped">
      <tbody>
      <tr>
        <td>Title : </td>
        <td>{{r.title_suggest}}</td>
      </tr>
      <tr>
        <td>Author : </td>
        <td>{{r.author_name[0]}}</td>
      </tr>
      <tr>
        <td>Year : </td>
        <td>{{r.publish_year[0]}}</td>
      </tr>
      <tr>
        <td>Place : </td>
        <td>{{r.place[0]}}</td>
      </tr>
      <tr>
        <td>Publisher : </td>
        <td>{{r.publisher[0]}}</td>
      </tr>
      <tr>
        <td>Lang : </td>
        <td>{{r.language[0]}}</td>
      </tr>

      </tbody>
    </table>
  </div>
  </div>
</template>

<script>
  const Axios = require('axios');

  export default {
    name: 'title1',
    props: {
      title1: {
        type:String,
      }
    },
    data() {
      return {
        r: '',
      };
    },

    created: async function(){
         const resp1 = await
         Axios.get(`http://openlibrary.org/search.json?q=${this.title1}`);
         this.r = resp1.data.docs[0];
         this.r = JSON.parse(this.r);
        return this.r;
    },
  };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .pad{
    padding: 20px;
  }

</style>
