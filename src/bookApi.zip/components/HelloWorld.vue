<template>

  <div class="bgg">
    <div class="card text-center bgg">
      <div class="card-header bgg">
      </div>
      <div class="pad">
        <b-card title="Find books"
                  img-src="https://images.pexels.com/photos/415078/pexels-photo-415078.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
                  img-alt="Image"
                  img-top
                  class="text-center"
                  tag="article"
                  style="max-width: 20rem; margin:0 auto"
          >
            <div class="card-text">
            <form>
              <div class="form-group">
                <input type="text"
                       v-model="text"
                       class="form-control"
                       id="exampleInputEmail1"
                       aria-describedby="emailHelp"
                       placeholder="Enter text">
              </div>
          </form>
            </div>
            <b-button @click="getData()" variant="primary">Print</b-button>
          </b-card>
        </div>
      <p>copyright
        <i style="font-size: medium; color: #1c7430;">GARIMA SINGH</i>
        Developer@bitqit</p>
     </div>
        <!--<div class="pad">-->
        <!--<ul class="list-group">-->
          <!--<li class="list-group-item d-flex justify-content-between align-items-center"-->
            <!--v-for="(index,item) in response" :key="item.id">-->
          <!--{{index.title_suggest}}-->
          <!--<b-button @click="getTitle(index.title_suggest)" variant="primary">Print</b-button>-->
        <!--</li>-->
      <!--</ul>-->
      <!--</div>-->
  </div>
</template>

<script>
const Axios = require('axios');
export default {
  name: 'HelloWorld',
  data() {
    return {
      text: '',
      kkk: 'nasa',
      response: '',
    };
  },
  methods: {
     async getData() {
      const resp =await Axios.get(`http://openlibrary.org/search.json?q=${this.text}`);
      this.response = resp.data.docs;
      //this.response = JSON.parse(this.response);

      this.$router.push({
        name: 'Data',
        params: { Data: this.response },
      });

    },

  },
};
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .pad{
    padding: 20px;
  }
  input {
    background-color:darkgrey;
  }
  /*.bgg{*/
    /*background: linear-gradient(whitesmoke, grey,lightblue);*/
  /*}*/

</style>
