<template>
  <div id="app">

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>


  body{
    background: linear-gradient(310deg, rgba(0,0,255,.8), rgba(0,0,255,0) 70.71%); /* Old browsers */

  }

  .card {

    background-color: transparent !important;


  }

#app {

}
</style>
