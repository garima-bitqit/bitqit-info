import Vue from 'vue';
import BootstrapVue from 'bootstrap-vue';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Pagination } from 'bootstrap-vue/es/components';
import bPagination from 'bootstrap-vue/es/components/pagination/pagination';
import 'bootstrap-vue/dist/bootstrap-vue.css';
import Router from 'vue-router';
import HelloWorld from '../components/HelloWorld';
import title1 from '../components/title1';
import Data from '../components/Data';

Vue.use(BootstrapVue);
Vue.use(Router);
Vue.use(Pagination);
Vue.component('b-pagination', bPagination);


export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld,
    },
    {
      path: '/book/:title1',
      name: 'title1',
      component: title1,
      props: true,
    },
    {
      path: '/data/:Data',
      name: 'Data',
      component: Data,
      props: true,
    },
  ],
});
